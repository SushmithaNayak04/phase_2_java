package demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class VisitCounter
 */
@WebServlet("/VisitCounter")
public class VisitCounter extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	int i=0;
	
	public void init()    //when the servlet goes to the container for the first time it will call init () and service().
	                      //In the second time only service will be executed.
	{
		i=1;
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VisitCounter() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest req, HttpServletResponse res) throws IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out= res.getWriter();
		out.println(i);
		i++;
		
		
	}


}
