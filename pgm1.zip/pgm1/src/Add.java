

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Add
 */
@WebServlet("/Add")
public class Add extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public Add() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		 response.setContentType("text/html");
		 
		 //try
	      //  {
		int i =Integer.parseInt(request.getParameter("t1"));
		int j =Integer.parseInt(request.getParameter("t2"));
		int k=i+j;
		
		/*out.println("<HTML>");
        out.println("<HEAD><TITLE>Hello</TITLE></HEAD>");
        out.println("<BODY>");
        out.println("First No.<input type=text value=" +i +"><br><br>");
        out.println("Second No.<input type=text value=" +j +"><br><br>");
        out.println("Output No:<input type=text value=" +k +"><br><br>");
        out.println("<input type=submit value=submit>");
        out.println("</BODY></HTML>");*/
		
		
		out.println(k); //}
		
		 /* catch(Exception e)
	        {
	        out.println("Invalid Input");
	        }*/

	

}
}
